
# GCP Dataplex Terraform Bundle

This Terraform configuration sets up a Google Cloud Platform environment for a Dataplex-based data lake with integrated BigQuery datasets and raw data ingestion.

## 📦 Included Terraform Files

- `main.tf`: Enables APIs, creates GCS bucket and BigQuery dataset
- `dataplex.tf`: Creates Dataplex lake and raw zone, uploads sample data, assigns IAM
- `variables.tf`: Input variables like project ID, region, bucket name, etc.
- `outputs.tf`: Shows bucket and dataset details after deployment

---

## 🧪 Prerequisites

- Google Cloud project with billing enabled
- `terraform` CLI installed
- Local copies of: `customers.csv`, `transactions.csv`, `support_logs.csv`

---

## 🚀 Usage

1. Customize `terraform.tfvars` or pass variables via CLI:

```bash
terraform init

terraform apply \
  -var="project_id=your-gcp-project" \
  -var="region=europe-west1" \
  -var="bucket_name=your-bucket-name" \
  -var="dataset_id=your_dataset" \
  -var="dataplex_user=you@example.com"
```

2. After deployment:
- Raw CSVs will be available in the GCS bucket under `/raw/`
- BigQuery dataset is created and ready for querying
- Dataplex lake and raw zone are created
- IAM viewer access is granted to the specified user

---

## 🔁 Next Steps

- Create **curated** and **analytics** zones in Dataplex manually or with Terraform
- Register BigQuery tables as Dataplex assets (see below)
- Apply governance tags and metadata policies in Dataplex

---

## 📚 Auto-register BigQuery Tables in Dataplex

To register BigQuery tables in Dataplex programmatically, add:

```hcl
resource "google_dataplex_asset" "customers_asset" {
  name     = "customers"
  asset_id = "customers"
  location = var.region
  lake     = google_dataplex_lake.lake.name
  zone     = google_dataplex_zone.raw_zone.name
  project  = var.project_id

  discovery_spec {
    enabled = true
  }

  resource_spec {
    name = "projects/${var.project_id}/datasets/${var.dataset_id}/tables/customers"
    type = "BIGQUERY_TABLE"
  }
}
```

Repeat for `transactions` and `support_logs`.

---

## ✅ Outcome

You’ll have a working GCP environment with:
- A governed Dataplex lake and raw zone
- Uploaded raw data and registered BigQuery tables
- A foundation for analytics, AI, and GenAI integration
